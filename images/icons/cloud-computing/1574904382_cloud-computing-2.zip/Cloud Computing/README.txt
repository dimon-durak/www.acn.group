Cloud Computing
===============

Designer: Shawn Rubel (https://www.iconfinder.com/Vecteezy)
License: Creative Commons (Attribution-Share Alike 3.0 Unported) (http://creativecommons.org/licenses/by-sa/3.0/)
